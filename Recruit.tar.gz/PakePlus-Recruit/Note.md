## 我应该下载哪个版本？

### MacOS

-   MacOS intel 芯片: x64.dmg
-   MacOS apple M 芯片: aarch64.dmg

### Linux

-   Linux 64 位: amd64.deb/amd64.rpm
-   Linux arm64 architecture: arm64.deb/aarch64.rpm
-   Linux armv7 架构: armhf.deb/armhfp.rpm

### Windows

-   64 位: x64-setup.exe
-   arm64 架构: arm64-setup.exe
